this archive holds no xml member
